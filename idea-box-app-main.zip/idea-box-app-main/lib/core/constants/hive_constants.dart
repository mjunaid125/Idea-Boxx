abstract class HiveConstants {
  static const String noteBox = 'noteBox';
  static const String noteList = 'noteList';
}