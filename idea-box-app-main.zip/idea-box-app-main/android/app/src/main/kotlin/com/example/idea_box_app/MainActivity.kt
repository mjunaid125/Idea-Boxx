package com.example.idea_box_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
